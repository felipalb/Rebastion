import Foundation
import Observation
import CoreGraphics

enum GamePhase: Equatable {
    case intro
    case playing
    case choosingUpgrade
    case gameOver
}

struct Projectile: Identifiable {
    let id = UUID()
    var position: CGPoint
    var velocity: CGVector
    var damage: Double
    var remainingHits: Int
    let isCritical: Bool
}

struct Enemy: Identifiable {
    let id = UUID()
    var position: CGPoint
    var health: Double
    let maxHealth: Double
    let radius: CGFloat
    let speed: CGFloat
    let isElite: Bool
    let kind: EnemyKind
}

struct Trail: Identifiable {
    let id = UUID()
    var position: CGPoint
    var radius: CGFloat
    var opacity: Double
}

enum EnemyKind: CaseIterable, Equatable {
    case grunt
    case runner
    case tank
    case splitter
    case boss

    var shortName: String {
        switch self {
        case .grunt: ""
        case .runner: "R"
        case .tank: "T"
        case .splitter: "2"
        case .boss: "BOSS"
        }
    }
}

enum WaveModifier: CaseIterable, Equatable {
    case standard
    case frenzy
    case armored
    case swarm

    var title: String {
        switch self {
        case .standard: "INVASÃO"
        case .frenzy: "FRENESI"
        case .armored: "BLINDADOS"
        case .swarm: "ENXAME"
        }
    }
}

enum HeroCosmetic: String, CaseIterable, Identifiable, Hashable {
    case ionCrown
    case voidCape
    case shoulderPods
    case plasmaOrbit
    case reactorHalo
    case starCore

    var id: String { rawValue }

    var title: String {
        switch self {
        case .ionCrown: "Coroa de Íons"
        case .voidCape: "Capa do Vazio"
        case .shoulderPods: "Pods de Combate"
        case .plasmaOrbit: "Satélites de Plasma"
        case .reactorHalo: "Halo de Reator"
        case .starCore: "Núcleo Estelar"
        }
    }

    var symbol: String {
        switch self {
        case .ionCrown: "crown.fill"
        case .voidCape: "wind"
        case .shoulderPods: "capsule.fill"
        case .plasmaOrbit: "atom"
        case .reactorHalo: "circle.hexagongrid.fill"
        case .starCore: "star.fill"
        }
    }
}

enum UpgradeRarity: Int {
    case common
    case rare
    case legendary

    var label: String {
        switch self {
        case .common: "COMUM"
        case .rare: "RARO"
        case .legendary: "LENDÁRIO"
        }
    }
}

enum Upgrade: String, CaseIterable, Identifiable, Hashable {
    case extraBall
    case heavyCore
    case overdrive
    case fortify
    case criticalMass
    case piercingRounds
    case rapidVolley
    case lifeSteal
    case pulseReactor
    case cryoCore
    case bountyHunter
    case lastStand

    var id: String { rawValue }

    var title: String {
        switch self {
        case .extraBall: "Bola Gêmea"
        case .heavyCore: "Núcleo Pesado"
        case .overdrive: "Sobrecarga"
        case .fortify: "Escudo de Pulso"
        case .criticalMass: "Massa Crítica"
        case .piercingRounds: "Perfuração Quântica"
        case .rapidVolley: "Gatilho Neural"
        case .lifeSteal: "Sifão Vital"
        case .pulseReactor: "Reator de Pulso"
        case .cryoCore: "Núcleo Criogênico"
        case .bountyHunter: "Caçador de Recompensa"
        case .lastStand: "Última Resistência"
        }
    }

    var detail: String {
        switch self {
        case .extraBall: "+1 tiro por rajada · −10% de dano por tiro"
        case .heavyCore: "+12 de dano · cadência 12% mais lenta"
        case .overdrive: "+30% velocidade e +10% cadência"
        case .fortify: "+1 vida e recarrega 35% do Pulso"
        case .criticalMass: "+15% crítico triplo · −8% dano base"
        case .piercingRounds: "+2 inimigos atravessados · −15% velocidade"
        case .rapidVolley: "+28% cadência · −3 de dano"
        case .lifeSteal: "Cure 1 vida a cada 12 abates"
        case .pulseReactor: "+50% recarga e dano do Pulso · −10% dano dos tiros"
        case .cryoCore: "Inimigos 18% mais lentos · mas ganham 10% de vida"
        case .bountyHunter: "+60% pontos · elites aparecem com mais frequência"
        case .lastStand: "+65% dano quando resta apenas 1 vida"
        }
    }

    var symbol: String {
        switch self {
        case .extraBall: "circle.grid.2x2.fill"
        case .heavyCore: "scope"
        case .overdrive: "bolt.fill"
        case .fortify: "shield.lefthalf.filled"
        case .criticalMass: "burst.fill"
        case .piercingRounds: "arrow.up.and.down.and.arrow.left.and.right"
        case .rapidVolley: "timer"
        case .lifeSteal: "heart.text.clipboard.fill"
        case .pulseReactor: "sun.max.trianglebadge.exclamationmark.fill"
        case .cryoCore: "snowflake"
        case .bountyHunter: "target"
        case .lastStand: "flame.fill"
        }
    }

    var rarity: UpgradeRarity {
        switch self {
        case .lastStand, .lifeSteal: .legendary
        case .criticalMass, .pulseReactor, .cryoCore, .bountyHunter: .rare
        default: .common
        }
    }
}

@MainActor
@Observable
final class GameEngine {
    private(set) var phase: GamePhase = .intro
    private(set) var enemies: [Enemy] = []
    private(set) var projectiles: [Projectile] = []
    private(set) var trails: [Trail] = []
    private(set) var wave = 1
    private(set) var level = 1
    private(set) var score = 0
    private(set) var lives = 3
    private(set) var experience = 0
    private(set) var upgradeChoices: [Upgrade] = []
    private(set) var waveModifier: WaveModifier = .standard
    private(set) var combo = 0
    private(set) var bestCombo = 0
    private(set) var specialEnergy = 1.0
    private(set) var specialHoldProgress = 0.0
    private(set) var shockwaveProgress = 0.0
    private(set) var upgradeLevels: [Upgrade: Int] = [:]
    private(set) var aimTarget: CGPoint?
    private(set) var isAiming = false
    private(set) var lastUpgrade: Upgrade?
    private(set) var lastCosmetic: HeroCosmetic?
    private(set) var upgradeToastRemaining = 0.0
    private(set) var upgradeLockRemaining = 0.0
    private(set) var cosmeticLevels: [HeroCosmetic: Int] = [:]

    private var enemiesToSpawn = 0
    private var spawnCooldown: Double = 0
    private var projectileCount = 1
    private var projectileDamage = 12.0
    private var projectileSpeed: CGFloat = 410
    private var criticalChance = 0.05
    private var fireCooldown: Double = 0
    private var fireInterval = 0.42
    private var maxProjectileHits = 1
    private var specialDamage = 42.0
    private var specialEnergyGain = 1.0
    private var chillFactor = 0.0
    private var scoreBonus = 1.0
    private var enemyHealthBonus = 0.0
    private var eliteChanceBonus = 0
    private var lifeStealEvery = 0
    private var killsSinceHeal = 0
    private var lastStandBonus = 0.0
    private var comboTimer = 0.0
    private var isHoldingSpecial = false
    private var arenaTouchOrigin: CGPoint?
    private var specialTriggeredThisTouch = false
    private var elapsedTime = 0.0
    private var lastArenaSize: CGSize = .zero

    var experienceNeeded: Int { 45 + (level - 1) * 30 }
    var canShoot: Bool { phase == .playing && fireCooldown <= 0 && projectiles.count < 18 }
    var isSpecialReady: Bool { specialEnergy >= 0.999 }
    var comboMultiplier: Int { min(8, 1 + combo / 4) }
    var canChooseUpgrade: Bool { phase == .choosingUpgrade && upgradeLockRemaining <= 0 }
    var shotsPerVolley: Int { projectileCount }
    var displayedDamage: Int { Int(effectiveProjectileDamage.rounded()) }
    var shotsPerSecond: Double { 1 / fireInterval }
    var displayedCriticalChance: Int { Int((criticalChance * 100).rounded()) }
    var animationPhase: Double { elapsedTime }

    func upgradeLevel(for upgrade: Upgrade) -> Int {
        upgradeLevels[upgrade, default: 0]
    }

    func cosmeticLevel(for cosmetic: HeroCosmetic) -> Int {
        cosmeticLevels[cosmetic, default: 0]
    }

    func hasCosmetic(_ cosmetic: HeroCosmetic) -> Bool {
        cosmeticLevel(for: cosmetic) > 0
    }

    func launchOrigin(in size: CGSize) -> CGPoint {
        CGPoint(x: size.width / 2, y: max(28, size.height - 32))
    }

    func start(arenaSize: CGSize) {
        wave = 1
        level = 1
        score = 0
        lives = 3
        experience = 0
        projectileCount = 1
        projectileDamage = 12
        projectileSpeed = 410
        criticalChance = 0.05
        fireInterval = 0.42
        maxProjectileHits = 1
        specialDamage = 42
        specialEnergyGain = 1
        chillFactor = 0
        scoreBonus = 1
        enemyHealthBonus = 0
        eliteChanceBonus = 0
        lifeStealEvery = 0
        killsSinceHeal = 0
        lastStandBonus = 0
        combo = 0
        bestCombo = 0
        comboTimer = 0
        specialEnergy = 0.4
        specialHoldProgress = 0
        shockwaveProgress = 0
        isHoldingSpecial = false
        arenaTouchOrigin = nil
        specialTriggeredThisTouch = false
        aimTarget = nil
        isAiming = false
        lastUpgrade = nil
        lastCosmetic = nil
        upgradeToastRemaining = 0
        upgradeLockRemaining = 0
        upgradeLevels.removeAll()
        cosmeticLevels.removeAll()
        elapsedTime = 0
        projectiles.removeAll()
        trails.removeAll()
        phase = .playing
        prepareWave(in: arenaSize)
    }

    func fire(toward target: CGPoint, arenaSize: CGSize) {
        guard canShoot, arenaSize.width > 0, arenaSize.height > 0 else { return }
        let origin = launchOrigin(in: arenaSize)
        let dx = target.x - origin.x
        let dy = min(target.y - origin.y, -30)
        let length = max(1, hypot(dx, dy))
        let baseAngle = atan2(dy / length, dx / length)
        let spread: CGFloat = 0.11

        for index in 0..<projectileCount {
            let offset = CGFloat(index) - CGFloat(projectileCount - 1) / 2
            let angle = baseAngle + offset * spread
            let critical = Double.random(in: 0...1) < criticalChance
            projectiles.append(
                Projectile(position: origin,
                           velocity: CGVector(dx: cos(angle) * projectileSpeed,
                                              dy: sin(angle) * projectileSpeed),
                           damage: effectiveProjectileDamage * (critical ? 3 : 1),
                           remainingHits: maxProjectileHits,
                           isCritical: critical)
            )
        }
        fireCooldown = fireInterval
    }

    private var effectiveProjectileDamage: Double {
        projectileDamage * (lives == 1 ? 1 + lastStandBonus : 1)
    }

    func updateArenaTouch(at point: CGPoint, arenaSize: CGSize) {
        guard phase == .playing else { return }
        let clamped = CGPoint(x: min(max(12, point.x), max(12, arenaSize.width - 12)),
                              y: min(max(12, point.y), max(12, arenaSize.height - 76)))
        aimTarget = clamped
        isAiming = true

        if arenaTouchOrigin == nil {
            arenaTouchOrigin = clamped
            specialTriggeredThisTouch = false
            isHoldingSpecial = isSpecialReady
            specialHoldProgress = 0
        } else if let origin = arenaTouchOrigin {
            let movement = hypot(clamped.x - origin.x, clamped.y - origin.y)
            if movement > 26 {
                isHoldingSpecial = false
                specialHoldProgress = 0
            }
        }
    }

    func endArenaTouch() {
        isAiming = false
        arenaTouchOrigin = nil
        isHoldingSpecial = false
        specialTriggeredThisTouch = false
        if specialHoldProgress < 1 { specialHoldProgress = 0 }
    }

    func activateSpecial(in arenaSize: CGSize) {
        guard phase == .playing, isSpecialReady else { return }
        let size = arenaSize == .zero ? lastArenaSize : arenaSize
        specialEnergy = 0
        specialHoldProgress = 0
        isHoldingSpecial = false
        shockwaveProgress = 1

        var defeated: [Enemy] = []
        for index in enemies.indices {
            enemies[index].health -= specialDamage
            enemies[index].position.y = max(20, enemies[index].position.y - 55)
            if enemies[index].health <= 0 { defeated.append(enemies[index]) }
        }
        enemies.removeAll { $0.health <= 0 }
        defeated.forEach(registerDefeat)

        let origin = launchOrigin(in: size)
        for index in 0..<12 {
            let angle = (CGFloat(index) / 12) * (.pi * 2)
            projectiles.append(
                Projectile(position: origin,
                           velocity: CGVector(dx: cos(angle) * projectileSpeed * 0.82,
                                              dy: sin(angle) * projectileSpeed * 0.82),
                           damage: effectiveProjectileDamage * 0.7,
                           remainingHits: maxProjectileHits,
                           isCritical: false)
            )
        }
    }

    func update(deltaTime: Double, arenaSize: CGSize) {
        if phase == .choosingUpgrade {
            upgradeLockRemaining = max(0, upgradeLockRemaining - deltaTime)
            return
        }
        guard phase == .playing, arenaSize.width > 40, arenaSize.height > 80 else { return }
        lastArenaSize = arenaSize
        elapsedTime += deltaTime
        fireCooldown = max(0, fireCooldown - deltaTime)
        upgradeToastRemaining = max(0, upgradeToastRemaining - deltaTime)
        comboTimer = max(0, comboTimer - deltaTime)
        if comboTimer == 0 { combo = 0 }
        if isHoldingSpecial && isSpecialReady {
            specialHoldProgress = min(1, specialHoldProgress + deltaTime / 0.8)
            if specialHoldProgress >= 1, !specialTriggeredThisTouch {
                specialTriggeredThisTouch = true
                activateSpecial(in: arenaSize)
            }
        }
        shockwaveProgress = max(0, shockwaveProgress - deltaTime * 1.45)
        spawnCooldown -= deltaTime
        spawnIfNeeded(in: arenaSize)
        if canShoot {
            let defaultTarget = CGPoint(x: arenaSize.width / 2, y: 8)
            fire(toward: aimTarget ?? defaultTarget, arenaSize: arenaSize)
        }
        moveEnemies(deltaTime: deltaTime, in: arenaSize)
        moveProjectiles(deltaTime: deltaTime, in: arenaSize)
        resolveCollisions()
        fadeTrails(deltaTime: deltaTime)
        finishWaveIfNeeded()
    }

    func choose(_ upgrade: Upgrade, arenaSize: CGSize) {
        guard canChooseUpgrade else { return }
        switch upgrade {
        case .extraBall:
            projectileCount += 1
            projectileDamage *= 0.9
        case .heavyCore:
            projectileDamage += 12
            fireInterval = min(0.75, fireInterval * 1.12)
        case .overdrive:
            projectileSpeed *= 1.3
            fireInterval = max(0.16, fireInterval * 0.9)
        case .fortify:
            lives += 1
            specialEnergy = min(1, specialEnergy + 0.35)
        case .criticalMass:
            criticalChance = min(0.7, criticalChance + 0.15)
            projectileDamage *= 0.92
        case .piercingRounds:
            maxProjectileHits += 2
            projectileSpeed *= 0.85
        case .rapidVolley:
            fireInterval = max(0.13, fireInterval * 0.72)
            projectileDamage = max(5, projectileDamage - 3)
        case .lifeSteal:
            lifeStealEvery = max(7, lifeStealEvery == 0 ? 12 : lifeStealEvery - 1)
        case .pulseReactor:
            specialDamage *= 1.5
            specialEnergyGain *= 1.5
            projectileDamage *= 0.9
        case .cryoCore:
            chillFactor = min(0.58, chillFactor + 0.18)
            enemyHealthBonus += 0.1
        case .bountyHunter:
            scoreBonus += 0.6
            eliteChanceBonus += 8
        case .lastStand:
            lastStandBonus += 0.65
        }
        upgradeLevels[upgrade, default: 0] += 1
        grantCosmetic()
        lastUpgrade = upgrade
        upgradeToastRemaining = 2.2
        level += 1
        wave += 1
        phase = .playing
        prepareWave(in: arenaSize == .zero ? lastArenaSize : arenaSize)
    }

    private func grantCosmetic() {
        let lowestLevel = HeroCosmetic.allCases
            .map { cosmeticLevels[$0, default: 0] }
            .min() ?? 0
        let candidates = HeroCosmetic.allCases.filter {
            cosmeticLevels[$0, default: 0] == lowestLevel
        }
        guard let cosmetic = candidates.randomElement() else { return }
        cosmeticLevels[cosmetic, default: 0] += 1
        lastCosmetic = cosmetic
    }

    private func prepareWave(in size: CGSize) {
        lastArenaSize = size
        enemies.removeAll()
        projectiles.removeAll()
        waveModifier = wave == 1 ? .standard : WaveModifier.allCases.randomElement() ?? .standard
        let baseCount = 7 + wave * 3
        enemiesToSpawn = waveModifier == .swarm ? Int(Double(baseCount) * 1.45) : baseCount
        spawnCooldown = 0.15
    }

    private func spawnIfNeeded(in size: CGSize) {
        guard enemiesToSpawn > 0, spawnCooldown <= 0 else { return }
        let isBoss = wave.isMultiple(of: 5) && enemiesToSpawn == 1
        let kind: EnemyKind
        if isBoss {
            kind = .boss
        } else {
            let roll = Int.random(in: 0..<100)
            if wave >= 4 && roll < 13 { kind = .splitter }
            else if wave >= 3 && roll < 32 { kind = .tank }
            else if wave >= 2 && roll < 58 { kind = .runner }
            else { kind = .grunt }
        }
        let eliteRoll = Int.random(in: 0..<100)
        let elite = isBoss || (wave >= 3 && eliteRoll < 8 + wave + eliteChanceBonus)
        let radius: CGFloat
        switch kind {
        case .runner: radius = 13
        case .tank: radius = 23
        case .splitter: radius = 19
        case .boss: radius = 34
        case .grunt: radius = elite ? 24 : 18
        }
        let x = CGFloat.random(in: (radius + 8)...max(radius + 9, size.width - radius - 8))
        let healthScale = pow(1.22, Double(wave - 1)) * (1 + enemyHealthBonus)
        let modifierHealth = waveModifier == .armored ? 1.55 : 1
        let baseHealth: Double
        let speedScale: Double
        switch kind {
        case .grunt: (baseHealth, speedScale) = (22, 1)
        case .runner: (baseHealth, speedScale) = (13, 1.85)
        case .tank: (baseHealth, speedScale) = (58, 0.62)
        case .splitter: (baseHealth, speedScale) = (34, 0.9)
        case .boss: (baseHealth, speedScale) = (240, 0.48)
        }
        let eliteHealth = elite ? 1.7 : 1
        let health = baseHealth * healthScale * modifierHealth * eliteHealth
        let frenzySpeed = waveModifier == .frenzy ? 1.55 : 1
        enemies.append(
            Enemy(position: CGPoint(x: x, y: -radius),
                  health: health,
                  maxHealth: health,
                  radius: radius,
                  speed: CGFloat(Double(34 + wave * 3) * speedScale * frenzySpeed),
                  isElite: elite,
                  kind: kind)
        )
        enemiesToSpawn -= 1
        let spawnMultiplier = waveModifier == .swarm ? 0.55 : 1
        spawnCooldown = max(0.14, (0.55 - Double(wave) * 0.018) * spawnMultiplier)
    }

    private func moveEnemies(deltaTime: Double, in size: CGSize) {
        for index in enemies.indices {
            let movementScale = max(0.42, 1 - chillFactor)
            enemies[index].position.y += enemies[index].speed * movementScale * deltaTime
            let lateral: CGFloat
            switch enemies[index].kind {
            case .runner: lateral = 25
            case .splitter: lateral = 15
            case .boss: lateral = 20
            default: lateral = 8
            }
            let sway = sin(enemies[index].position.y * 0.028 + CGFloat(index) + elapsedTime) * lateral
            enemies[index].position.x = min(size.width - enemies[index].radius,
                                             max(enemies[index].radius, enemies[index].position.x + sway * deltaTime))
        }

        let escaped = enemies.filter { $0.position.y - $0.radius > size.height - 42 }.count
        guard escaped > 0 else { return }
        enemies.removeAll { $0.position.y - $0.radius > size.height - 42 }
        lives -= escaped
        if lives <= 0 {
            lives = 0
            projectiles.removeAll()
            phase = .gameOver
        } else {
            combo = 0
            comboTimer = 0
        }
    }

    private func moveProjectiles(deltaTime: Double, in size: CGSize) {
        for index in projectiles.indices {
            trails.append(Trail(position: projectiles[index].position, radius: 4, opacity: 0.28))
            projectiles[index].position.x += projectiles[index].velocity.dx * deltaTime
            projectiles[index].position.y += projectiles[index].velocity.dy * deltaTime

        }
        projectiles.removeAll {
            $0.position.x < -20 || $0.position.x > size.width + 20 ||
            $0.position.y < -20 || $0.position.y > size.height + 20 ||
            $0.remainingHits <= 0
        }
    }

    private func resolveCollisions() {
        var deadEnemyIDs = Set<UUID>()
        var defeatedEnemies: [Enemy] = []

        for projectileIndex in projectiles.indices {
            for enemyIndex in enemies.indices where !deadEnemyIDs.contains(enemies[enemyIndex].id) {
                let dx = projectiles[projectileIndex].position.x - enemies[enemyIndex].position.x
                let dy = projectiles[projectileIndex].position.y - enemies[enemyIndex].position.y
                let hitDistance = enemies[enemyIndex].radius + 6
                guard dx * dx + dy * dy <= hitDistance * hitDistance else { continue }

                enemies[enemyIndex].health -= projectiles[projectileIndex].damage
                projectiles[projectileIndex].remainingHits -= 1
                projectiles[projectileIndex].position.y -= 8

                if enemies[enemyIndex].health <= 0 {
                    deadEnemyIDs.insert(enemies[enemyIndex].id)
                    defeatedEnemies.append(enemies[enemyIndex])
                }
                break
            }
        }

        enemies.removeAll { deadEnemyIDs.contains($0.id) }
        defeatedEnemies.forEach { enemy in
            registerDefeat(enemy)
            if enemy.kind == .splitter {
                spawnSplitChildren(from: enemy)
            }
        }
    }

    private func registerDefeat(_ enemy: Enemy) {
        combo += 1
        bestCombo = max(bestCombo, combo)
        comboTimer = 2.6
        let baseReward: Int
        switch enemy.kind {
        case .runner: baseReward = 22
        case .tank: baseReward = 48
        case .splitter: baseReward = 42
        case .boss: baseReward = 250
        case .grunt: baseReward = enemy.isElite ? 80 : 25
        }
        score += Int(Double(baseReward * wave * comboMultiplier) * scoreBonus)
        addExperience(enemy.isElite ? 20 : 8)
        specialEnergy = min(1, specialEnergy + (enemy.isElite ? 0.24 : 0.075) * specialEnergyGain)

        if lifeStealEvery > 0 {
            killsSinceHeal += 1
            if killsSinceHeal >= lifeStealEvery {
                lives += 1
                killsSinceHeal = 0
            }
        }
    }

    private func spawnSplitChildren(from enemy: Enemy) {
        for direction in [-1.0, 1.0] {
            let health = max(8, enemy.maxHealth * 0.28)
            enemies.append(
                Enemy(position: CGPoint(x: enemy.position.x + CGFloat(direction * 12),
                                        y: enemy.position.y),
                      health: health,
                      maxHealth: health,
                      radius: 10,
                      speed: enemy.speed * 1.5,
                      isElite: false,
                      kind: .runner)
            )
        }
    }

    private func addExperience(_ amount: Int) {
        experience += amount
        while experience >= experienceNeeded {
            experience -= experienceNeeded
            level += 1
            projectileDamage += 2
        }
    }

    private func fadeTrails(deltaTime: Double) {
        for index in trails.indices {
            trails[index].opacity -= deltaTime * 2.7
            trails[index].radius *= 0.98
        }
        trails.removeAll { $0.opacity <= 0 }
        if trails.count > 220 { trails.removeFirst(trails.count - 220) }
    }

    private func finishWaveIfNeeded() {
        guard enemiesToSpawn == 0, enemies.isEmpty, phase == .playing else { return }
        projectiles.removeAll()
        aimTarget = nil
        isAiming = false
        arenaTouchOrigin = nil
        isHoldingSpecial = false
        specialHoldProgress = 0
        let available = Upgrade.allCases.filter { upgrade in
            switch upgrade.rarity {
            case .common: true
            case .rare: wave >= 2
            case .legendary: wave >= 4
            }
        }
        var pool = available
        if wave >= 4, let legendary = available.filter({ $0.rarity == .legendary }).randomElement(),
           Int.random(in: 0..<100) < 28 {
            pool.removeAll { $0 == legendary }
            upgradeChoices = [legendary] + Array(pool.shuffled().prefix(2))
        } else {
            upgradeChoices = Array(pool.shuffled().prefix(3))
        }
        upgradeLockRemaining = 0.85
        phase = .choosingUpgrade
    }
}
