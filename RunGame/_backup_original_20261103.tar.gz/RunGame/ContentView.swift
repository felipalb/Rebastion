import SwiftUI
import UIKit

struct ContentView: View {
    @State private var game = GameEngine()
    @State private var arenaSize: CGSize = .zero
    @State private var scoreStatus: ScoreStatus = .idle

    var body: some View {
        ZStack {
            GamePalette.background.ignoresSafeArea()

            VStack(spacing: 12) {
                header

                GeometryReader { proxy in
                    arena(size: proxy.size)
                        .onAppear { arenaSize = proxy.size }
                        .onChange(of: proxy.size) { _, size in arenaSize = size }
                }
                .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 28, style: .continuous)
                        .stroke(GamePalette.lime.opacity(0.22), lineWidth: 1)
                }
                .padding(.horizontal, 12)

                footer
            }
            .padding(.top, 8)
            .padding(.bottom, 10)

            overlay
        }
        .preferredColorScheme(.dark)
        .task {
            var previous = ContinuousClock.now
            while !Task.isCancelled {
                try? await Task.sleep(for: .milliseconds(16))
                let now = ContinuousClock.now
                let duration = previous.duration(to: now)
                previous = now
                let seconds = Double(duration.components.seconds)
                    + Double(duration.components.attoseconds) / 1_000_000_000_000_000_000
                game.update(deltaTime: min(seconds, 0.05), arenaSize: arenaSize)
            }
        }
        .onChange(of: game.phase) { oldValue, newValue in
            guard newValue == .gameOver, oldValue != .gameOver else { return }
            submitScore()
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Label("ONDA \(game.wave)", systemImage: "waveform.path.ecg")
                    .font(.caption.weight(.black))
                    .foregroundStyle(GamePalette.lime)
                Text(game.waveModifier.title)
                    .font(.system(.caption2, design: .rounded, weight: .bold))
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if game.combo > 1 {
                statPill(icon: "bolt.horizontal.fill",
                         value: "x\(game.comboMultiplier) · \(game.combo)",
                         color: .orange)
            }
            statPill(icon: "sparkles", value: "\(game.score)")
            statPill(icon: "heart.fill", value: "\(game.lives)", color: GamePalette.coral)
        }
        .padding(.horizontal, 18)
    }

    private var footer: some View {
        HStack(spacing: 16) {
            VStack(spacing: 8) {
                HStack(spacing: 6) {
                    buildStat(icon: "circle.grid.2x2.fill", value: "\(game.shotsPerVolley)x")
                    buildStat(icon: "scope", value: "\(game.displayedDamage)")
                    buildStat(icon: "timer", value: String(format: "%.1f/s", game.shotsPerSecond))
                    buildStat(icon: "burst.fill", value: "\(game.displayedCriticalChance)%")
                }

                HStack {
                    Text("NÍVEL \(game.level)")
                    Spacer()
                    Text("\(game.experience)/\(game.experienceNeeded) XP")
                }
                .font(.caption2.weight(.bold))
                .foregroundStyle(.secondary)

                ProgressView(value: Double(game.experience), total: Double(game.experienceNeeded))
                    .tint(GamePalette.cyan)
                    .scaleEffect(y: 1.7)
            }
            .accessibilityElement(children: .combine)
            .accessibilityLabel("Nível \(game.level), \(game.experience) de \(game.experienceNeeded) pontos de experiência")

            SpecialMeter(energy: game.specialEnergy,
                         holdProgress: game.specialHoldProgress,
                         isReady: game.isSpecialReady)
        }
        .padding(.horizontal, 20)
    }

    private func buildStat(icon: String, value: String) -> some View {
        Label(value, systemImage: icon)
            .font(.system(size: 10, weight: .black, design: .rounded))
            .foregroundStyle(.white.opacity(0.82))
            .lineLimit(1)
            .minimumScaleFactor(0.75)
            .padding(.horizontal, 7)
            .padding(.vertical, 5)
            .background(.white.opacity(0.06), in: Capsule())
    }

    private func statPill(icon: String, value: String, color: Color = GamePalette.cyan) -> some View {
        Label(value, systemImage: icon)
            .font(.caption.weight(.black))
            .foregroundStyle(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.white.opacity(0.07), in: Capsule())
    }

    private func arena(size: CGSize) -> some View {
        Canvas { context, canvasSize in
            drawGrid(context: context, size: canvasSize)

            for trail in game.trails {
                let rect = CGRect(x: trail.position.x - trail.radius,
                                  y: trail.position.y - trail.radius,
                                  width: trail.radius * 2,
                                  height: trail.radius * 2)
                context.opacity = trail.opacity
                context.fill(Path(ellipseIn: rect), with: .color(GamePalette.cyan))
            }
            context.opacity = 1

            for enemy in game.enemies { draw(enemy: enemy, in: &context) }

            for projectile in game.projectiles {
                draw(projectile: projectile, in: &context)
            }

            let origin = game.launchOrigin(in: canvasSize)
            if game.shockwaveProgress > 0 {
                let radius = (1 - game.shockwaveProgress) * max(canvasSize.width, canvasSize.height) * 0.9 + 24
                let pulse = CGRect(x: origin.x - radius,
                                   y: origin.y - radius,
                                   width: radius * 2,
                                   height: radius * 2)
                context.stroke(Path(ellipseIn: pulse),
                               with: .color(GamePalette.violet.opacity(game.shockwaveProgress)),
                               lineWidth: 5)
            }
            drawHero(at: origin,
                     aimingAt: game.aimTarget ?? CGPoint(x: canvasSize.width / 2, y: 0),
                     charge: game.specialHoldProgress,
                     in: &context)

            if let aimPoint = game.aimTarget, game.phase == .playing, game.isAiming {
                var path = Path()
                path.move(to: origin)
                path.addLine(to: aimPoint)
                context.stroke(path,
                               with: .color(.white.opacity(0.55)),
                               style: StrokeStyle(lineWidth: 2, dash: [7, 7]))
                drawReticle(at: aimPoint, in: &context)
            }
        }
        .background {
            LinearGradient(colors: [GamePalette.arenaTop, GamePalette.arenaBottom],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
        }
        .contentShape(Rectangle())
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    game.updateArenaTouch(at: value.location, arenaSize: size)
                }
                .onEnded { _ in
                    game.endArenaTouch()
                }
        )
        .overlay(alignment: .top) {
            if let upgrade = game.lastUpgrade, game.upgradeToastRemaining > 0 {
                UpgradeToast(upgrade: upgrade,
                             level: game.upgradeLevel(for: upgrade),
                             cosmetic: game.lastCosmetic,
                             cosmeticLevel: game.lastCosmetic.map(game.cosmeticLevel(for:)) ?? 0)
                    .padding(.top, 14)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .accessibilityLabel("Arena de combate")
        .accessibilityHint("Arraste para mirar. O herói dispara automaticamente. Mantenha o dedo parado para carregar o Pulso Nova")
        .accessibilityAction(named: "Ativar Pulso Nova") {
            if game.isSpecialReady { game.activateSpecial(in: size) }
        }
    }

    @ViewBuilder
    private var overlay: some View {
        switch game.phase {
        case .intro:
            IntroView { game.start(arenaSize: arenaSize) }
                .transition(.opacity.combined(with: .scale(scale: 0.96)))
        case .choosingUpgrade:
            UpgradeView(options: game.upgradeChoices,
                        levels: game.upgradeLevels,
                        canSelect: game.canChooseUpgrade) { upgrade in
                game.choose(upgrade, arenaSize: arenaSize)
            }
            .transition(.move(edge: .bottom).combined(with: .opacity))
        case .gameOver:
            GameOverView(game: game, scoreStatus: scoreStatus) {
                scoreStatus = .idle
                game.start(arenaSize: arenaSize)
            }
            .transition(.opacity)
        case .playing:
            EmptyView()
        }
    }

    private func drawGrid(context: GraphicsContext, size: CGSize) {
        var grid = Path()
        let step: CGFloat = 34
        stride(from: CGFloat.zero, through: size.width, by: step).forEach { x in
            grid.move(to: CGPoint(x: x, y: 0))
            grid.addLine(to: CGPoint(x: x, y: size.height))
        }
        stride(from: CGFloat.zero, through: size.height, by: step).forEach { y in
            grid.move(to: CGPoint(x: 0, y: y))
            grid.addLine(to: CGPoint(x: size.width, y: y))
        }
        context.stroke(grid, with: .color(.white.opacity(0.035)), lineWidth: 1)
    }

    private func draw(projectile: Projectile, in context: inout GraphicsContext) {
        let radius = min(CGFloat(10), CGFloat(4.2 + projectile.damage / 24))
        let color = projectile.isCritical ? GamePalette.coral : GamePalette.cyan
        let glow = CGRect(x: projectile.position.x - radius * 2.2,
                          y: projectile.position.y - radius * 2.2,
                          width: radius * 4.4,
                          height: radius * 4.4)
        context.fill(Path(glow), with: .color(color.opacity(0.16)))
        let ball = CGRect(x: projectile.position.x - radius,
                          y: projectile.position.y - radius,
                          width: radius * 2,
                          height: radius * 2)
        context.fill(Path(ball), with: .color(GamePalette.ink))
        context.fill(Path(ball.insetBy(dx: 2, dy: 2)), with: .color(color))
        context.fill(Path(ball.insetBy(dx: radius * 0.48, dy: radius * 0.48)),
                     with: .color(.white.opacity(0.9)))
    }

    private func drawHero(at origin: CGPoint,
                          aimingAt target: CGPoint,
                          charge: Double,
                          in context: inout GraphicsContext) {
        let dx = target.x - origin.x
        let dy = target.y - origin.y
        let length = max(1, hypot(dx, dy))
        let direction = CGVector(dx: dx / length, dy: dy / length)

        let bob = CGFloat(sin(game.animationPhase * 5.5)) * 1.5
        let heroCenter = CGPoint(x: origin.x, y: origin.y + bob)
        let shadow = CGRect(x: heroCenter.x - 23, y: heroCenter.y + 22, width: 46, height: 7)
        context.fill(Path(roundedRect: shadow, cornerRadius: 1), with: .color(.black.opacity(0.42)))

        drawHeroCosmetics(at: heroCenter, behindHero: true, in: &context)

        for step in 3...8 {
            let distance = CGFloat(step) * 4
            let point = CGPoint(x: heroCenter.x + direction.dx * distance,
                                y: heroCenter.y + direction.dy * distance)
            let block = CGRect(x: (point.x - 3).rounded(), y: (point.y - 3).rounded(), width: 6, height: 6)
            context.fill(Path(block), with: .color(step == 8 ? GamePalette.cyan : GamePalette.violet))
        }

        if let heroImage = CharacterAtlas.image(for: .hero) {
            let heroRect = CGRect(x: heroCenter.x - 40, y: heroCenter.y - 40, width: 80, height: 80)
            context.draw(heroImage, in: heroRect)
        } else {
            drawPixelSprite(PixelSprites.hero,
                            palette: ["N": GamePalette.ink,
                                      "C": GamePalette.cyan,
                                      "V": GamePalette.violet,
                                      "W": .white,
                                      "L": GamePalette.lime,
                                      "O": .orange],
                            center: heroCenter,
                            pixel: 3,
                            in: &context)
        }
        drawHeroCosmetics(at: heroCenter, behindHero: false, in: &context)

        if charge > 0 {
            let chargeRect = CGRect(x: heroCenter.x - 31, y: heroCenter.y - 31, width: 62, height: 62)
            let ring = Path(ellipseIn: chargeRect)
                .trimmedPath(from: 0, to: charge)
            context.stroke(ring, with: .color(GamePalette.lime),
                           style: StrokeStyle(lineWidth: 6, lineCap: .round))
        }
    }

    private func drawReticle(at point: CGPoint, in context: inout GraphicsContext) {
        let outer = CGRect(x: point.x - 17, y: point.y - 17, width: 34, height: 34)
        context.stroke(Path(ellipseIn: outer), with: .color(GamePalette.lime.opacity(0.85)), lineWidth: 2)
        var cross = Path()
        cross.move(to: CGPoint(x: point.x - 23, y: point.y))
        cross.addLine(to: CGPoint(x: point.x - 8, y: point.y))
        cross.move(to: CGPoint(x: point.x + 8, y: point.y))
        cross.addLine(to: CGPoint(x: point.x + 23, y: point.y))
        cross.move(to: CGPoint(x: point.x, y: point.y - 23))
        cross.addLine(to: CGPoint(x: point.x, y: point.y - 8))
        cross.move(to: CGPoint(x: point.x, y: point.y + 8))
        cross.addLine(to: CGPoint(x: point.x, y: point.y + 23))
        context.stroke(cross, with: .color(GamePalette.lime), lineWidth: 2)
    }

    private func draw(enemy: Enemy, in context: inout GraphicsContext) {
        let ratio = max(0, enemy.health / enemy.maxHealth)
        let color: Color
        switch enemy.kind {
        case .runner: color = GamePalette.cyan
        case .tank: color = .orange
        case .splitter: color = GamePalette.violet
        case .boss: color = GamePalette.coral
        case .grunt: color = enemy.isElite ? GamePalette.coral : GamePalette.lime
        }

        let bobSpeed = enemy.kind == .runner ? 11.0 : 5.0
        let bob = CGFloat(sin(game.animationPhase * bobSpeed + Double(enemy.position.x))) * 1.5
        let center = CGPoint(x: enemy.position.x, y: enemy.position.y + bob)
        let spriteSide = enemy.radius * (enemy.kind == .boss ? 3.45 : 3.75)
        let spriteWidth = spriteSide
        let spriteHeight = spriteSide
        let shadow = CGRect(x: center.x - spriteWidth * 0.4,
                            y: center.y + spriteHeight * 0.42,
                            width: spriteWidth * 0.8,
                            height: max(3, enemy.radius * 0.16))
        context.fill(Path(roundedRect: shadow, cornerRadius: 1), with: .color(.black.opacity(0.38)))
        let atlasSprite = CharacterAtlas.Sprite(enemyKind: enemy.kind)
        if let enemyImage = CharacterAtlas.image(for: atlasSprite) {
            let imageRect = CGRect(x: center.x - spriteSide / 2,
                                   y: center.y - spriteSide / 2,
                                   width: spriteSide,
                                   height: spriteSide)
            if enemy.isElite {
                context.fill(Path(ellipseIn: imageRect.insetBy(dx: 3, dy: 3)),
                             with: .color(.white.opacity(0.12)))
            }
            context.draw(enemyImage, in: imageRect)
        }

        let rect = CGRect(x: center.x - spriteWidth / 2,
                          y: center.y - spriteHeight / 2,
                          width: spriteWidth,
                          height: spriteHeight)
        let healthBack = CGRect(x: rect.minX, y: rect.minY - 7, width: rect.width, height: 4)
        let healthFill = CGRect(x: healthBack.minX, y: healthBack.minY,
                                width: healthBack.width * ratio, height: healthBack.height)
        context.fill(Path(healthBack), with: .color(.black.opacity(0.65)))
        context.fill(Path(healthFill), with: .color(enemy.isElite ? .white : color))
    }

    private func drawHeroCosmetics(at center: CGPoint,
                                   behindHero: Bool,
                                   in context: inout GraphicsContext) {
        if behindHero {
            if game.hasCosmetic(.reactorHalo) {
                let level = CGFloat(game.cosmeticLevel(for: .reactorHalo))
                let halo = CGRect(x: center.x - 34 - level,
                                  y: center.y - 34 - level,
                                  width: 68 + level * 2,
                                  height: 68 + level * 2)
                context.stroke(Path(ellipseIn: halo), with: .color(GamePalette.cyan.opacity(0.42)), lineWidth: 3)
            }
            if game.hasCosmetic(.voidCape) {
                let level = CGFloat(game.cosmeticLevel(for: .voidCape))
                for row in 0..<6 {
                    let block = CGRect(x: center.x + 19 + CGFloat(row) * 2,
                                       y: center.y - 5 + CGFloat(row) * 6,
                                       width: 12 + level,
                                       height: 7)
                    context.fill(Path(block), with: .color(GamePalette.violet.opacity(0.82)))
                }
            }
            return
        }

        if game.hasCosmetic(.ionCrown) {
            let y = center.y - 37
            for (offset, height) in [(-12.0, 8.0), (0.0, 13.0), (12.0, 8.0)] {
                let block = CGRect(x: center.x + offset - 4, y: y - height, width: 8, height: height)
                context.fill(Path(block), with: .color(.yellow))
                context.fill(Path(block.insetBy(dx: 2, dy: 2)), with: .color(.orange))
            }
        }
        if game.hasCosmetic(.shoulderPods) {
            for direction in [-1.0, 1.0] {
                let pod = CGRect(x: center.x + CGFloat(direction) * 31 - 6,
                                 y: center.y - 9,
                                 width: 12,
                                 height: 18)
                context.fill(Path(pod), with: .color(GamePalette.ink))
                context.fill(Path(pod.insetBy(dx: 2, dy: 2)), with: .color(.orange))
            }
        }
        if game.hasCosmetic(.plasmaOrbit) {
            let count = min(4, game.cosmeticLevel(for: .plasmaOrbit) + 1)
            for index in 0..<count {
                let angle = game.animationPhase * 2.2 + Double(index) * (.pi * 2 / Double(count))
                let point = CGPoint(x: center.x + cos(angle) * 40,
                                    y: center.y + sin(angle) * 24)
                let satellite = CGRect(x: point.x - 4, y: point.y - 4, width: 8, height: 8)
                context.fill(Path(satellite), with: .color(GamePalette.lime))
            }
        }
        if game.hasCosmetic(.starCore) {
            let core = CGRect(x: center.x - 5, y: center.y - 2, width: 10, height: 10)
            context.fill(Path(core), with: .color(.yellow))
            context.fill(Path(core.insetBy(dx: 3, dy: 3)), with: .color(.white))
        }
    }

    private func drawPixelSprite(_ pattern: [String],
                                 palette: [Character: Color],
                                 center: CGPoint,
                                 pixel: CGFloat,
                                 in context: inout GraphicsContext) {
        let columns = pattern.map(\.count).max() ?? 0
        let originX = (center.x - CGFloat(columns) * pixel / 2).rounded()
        let originY = (center.y - CGFloat(pattern.count) * pixel / 2).rounded()
        for (row, line) in pattern.enumerated() {
            for (column, character) in line.enumerated() {
                guard let color = palette[character] else { continue }
                let rect = CGRect(x: originX + CGFloat(column) * pixel,
                                  y: originY + CGFloat(row) * pixel,
                                  width: pixel + 0.25,
                                  height: pixel + 0.25)
                context.fill(Path(rect), with: .color(color))
            }
        }
    }

    private func submitScore() {
        scoreStatus = .sending
        let entry = ScoreEntry(player: "Runner", score: game.score, wave: game.wave)
        Task {
            do {
                try await ScoreService.local.submit(entry)
                scoreStatus = .sent
            } catch {
                scoreStatus = .offline
            }
        }
    }
}

private struct IntroView: View {
    let start: () -> Void

    var body: some View {
        modalCard {
            VStack(spacing: 18) {
                ZStack {
                    Circle().fill(GamePalette.violet.opacity(0.3)).frame(width: 110, height: 110)
                    Image(systemName: "circle.hexagongrid.fill")
                        .font(.system(size: 68, weight: .black))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(GamePalette.cyan, GamePalette.violet)
                }

                VStack(spacing: 4) {
                    Text("NEON SIEGE")
                        .font(.largeTitle.weight(.black))
                        .tracking(-1.2)
                    Text("Construa uma máquina de caos, uma onda por vez.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                VStack(alignment: .leading, spacing: 10) {
                    instruction("circle.circle.fill", "O herói dispara automaticamente")
                    instruction("hand.draw.fill", "Arraste na arena para mover a mira")
                    instruction("hand.tap.fill", "Mantenha o dedo parado para ativar o Pulso Nova")
                    instruction("arrow.up.right.and.arrow.down.left", "Escolha upgrades e quebre o jogo")
                }

                Button(action: start) {
                    Label("COMEÇAR RUN", systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryButtonStyle())
                .accessibilityIdentifier("start-run")
            }
        }
    }

    private func instruction(_ symbol: String, _ text: String) -> some View {
        Label(text, systemImage: symbol)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white.opacity(0.88))
    }
}

private struct UpgradeView: View {
    let options: [Upgrade]
    let levels: [Upgrade: Int]
    let canSelect: Bool
    let select: (Upgrade) -> Void

    var body: some View {
        modalCard {
            VStack(spacing: 16) {
                Text("MUTAÇÃO DISPONÍVEL")
                    .font(.title2.weight(.black))
                    .foregroundStyle(GamePalette.lime)
                Text("Escolha uma mudança de build. Poder alto agora vem com consequências.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                Label(canSelect ? "ESCOLHA COM CALMA — O JOGO ESTÁ PAUSADO" : "ESTABILIZANDO A ARENA…",
                      systemImage: canSelect ? "pause.fill" : "hourglass")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(canSelect ? GamePalette.cyan : .secondary)
                    .animation(.easeInOut, value: canSelect)

                Label("BÔNUS DA ONDA: VISUAL SURPRESA PARA O HERÓI",
                      systemImage: "tshirt.fill")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(.orange)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(.orange.opacity(0.12), in: Capsule())

                ForEach(options) { upgrade in
                    Button { select(upgrade) } label: {
                        HStack(spacing: 14) {
                            Image(systemName: upgrade.symbol)
                                .font(.title2.weight(.bold))
                                .frame(width: 48, height: 48)
                                .background(upgrade.color.opacity(0.18), in: RoundedRectangle(cornerRadius: 14))
                                .foregroundStyle(upgrade.color)
                            VStack(alignment: .leading, spacing: 3) {
                                HStack(spacing: 6) {
                                    Text(upgrade.title).font(.headline)
                                    Text(upgrade.rarity.label)
                                        .font(.system(size: 9, weight: .black))
                                        .foregroundStyle(upgrade.rarity.color)
                                        .padding(.horizontal, 5)
                                        .padding(.vertical, 2)
                                        .background(upgrade.rarity.color.opacity(0.14), in: Capsule())
                                }
                                Text(upgrade.detail).font(.caption).foregroundStyle(.secondary)
                                Text("NÍVEL \(levels[upgrade, default: 0]) → \(levels[upgrade, default: 0] + 1)")
                                    .font(.caption2.weight(.black))
                                    .foregroundStyle(upgrade.color)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").foregroundStyle(.tertiary)
                        }
                        .padding(12)
                        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
                        .overlay {
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(upgrade.rarity.color.opacity(0.42), lineWidth: 1)
                        }
                    }
                    .buttonStyle(.plain)
                    .frame(minHeight: 64)
                    .disabled(!canSelect)
                    .opacity(canSelect ? 1 : 0.62)
                }
            }
        }
    }
}

private struct SpecialMeter: View {
    let energy: Double
    let holdProgress: Double
    let isReady: Bool

    var body: some View {
        VStack(spacing: 3) {
            ZStack {
                Circle().fill(.white.opacity(0.06))
                Circle()
                    .trim(from: 0, to: max(0.02, energy))
                    .stroke(isReady ? GamePalette.violet : .white.opacity(0.3),
                            style: StrokeStyle(lineWidth: 5, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                if isReady {
                    Circle()
                        .trim(from: 0, to: holdProgress)
                        .stroke(GamePalette.cyan,
                                style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .padding(7)
                }
                VStack(spacing: 1) {
                    Image(systemName: "sun.max.trianglebadge.exclamationmark.fill")
                        .font(.title3.weight(.black))
                        .symbolRenderingMode(.hierarchical)
                        .symbolEffect(.pulse, options: .repeating, isActive: isReady)
                    Text(isReady ? (holdProgress > 0 ? "!" : "OK") : "\(Int(energy * 100))%")
                        .font(.system(size: 8, weight: .black))
                }
                .foregroundStyle(isReady ? GamePalette.cyan : .secondary)
            }
            .frame(width: 58, height: 58)

            Text(isReady ? "SEGURE NA ARENA" : "PULSO")
                .font(.system(size: 7, weight: .black, design: .rounded))
                .foregroundStyle(isReady ? GamePalette.cyan : .secondary)
                .lineLimit(1)
        }
        .frame(width: 82)
        .allowsHitTesting(false)
        .accessibilityLabel("Pulso Nova")
        .accessibilityValue(isReady ? "Pronto" : "\(Int(energy * 100)) por cento")
        .accessibilityHint("Mantenha um dedo parado na arena para causar dano em todos os inimigos")
    }
}

private struct UpgradeToast: View {
    let upgrade: Upgrade
    let level: Int
    let cosmetic: HeroCosmetic?
    let cosmeticLevel: Int

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: upgrade.symbol)
                .font(.headline.weight(.black))
                .foregroundStyle(upgrade.color)
            VStack(alignment: .leading, spacing: 1) {
                Text("MUTAÇÃO ATIVA")
                    .font(.system(size: 8, weight: .black, design: .rounded))
                    .foregroundStyle(.secondary)
                Text("\(upgrade.title) · NÍVEL \(level)")
                    .font(.caption.weight(.black))
                if let cosmetic {
                    Label("\(cosmetic.title) · VISUAL \(cosmeticLevel)", systemImage: cosmetic.symbol)
                        .font(.system(size: 9, weight: .black, design: .rounded))
                        .foregroundStyle(.orange)
                }
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay { Capsule().stroke(upgrade.color.opacity(0.5), lineWidth: 1) }
        .shadow(color: upgrade.color.opacity(0.22), radius: 12)
    }
}

private struct GameOverView: View {
    let game: GameEngine
    let scoreStatus: ScoreStatus
    let restart: () -> Void

    var body: some View {
        modalCard {
            VStack(spacing: 16) {
                Image(systemName: "bolt.heart.fill")
                    .font(.system(size: 52))
                    .symbolRenderingMode(.palette)
                    .foregroundStyle(GamePalette.coral, GamePalette.violet)
                Text("RUN ENCERRADA").font(.title.weight(.black))
                HStack(spacing: 28) {
                    result("PONTOS", "\(game.score)")
                    result("ONDA", "\(game.wave)")
                    result("MELHOR COMBO", "\(game.bestCombo)")
                }
                Label(scoreStatus.label, systemImage: scoreStatus.symbol)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button(action: restart) {
                    Label("JOGAR DE NOVO", systemImage: "arrow.clockwise")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryButtonStyle())
            }
        }
    }

    private func result(_ title: String, _ value: String) -> some View {
        VStack(spacing: 4) {
            Text(value).font(.title2.monospacedDigit().weight(.black))
            Text(title).font(.caption2.weight(.bold)).foregroundStyle(.secondary)
        }
    }
}

private func modalCard<Content: View>(@ViewBuilder content: () -> Content) -> some View {
    ZStack {
        Color.black.opacity(0.72)
            .ignoresSafeArea()
            .contentShape(Rectangle())
            .onTapGesture { }
        content()
            .padding(24)
            .frame(maxWidth: 420)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 28, style: .continuous)
                    .stroke(.white.opacity(0.1), lineWidth: 1)
            }
            .padding(20)
    }
}

private struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline.weight(.black))
            .padding(.vertical, 15)
            .foregroundStyle(GamePalette.background)
            .background(GamePalette.lime, in: RoundedRectangle(cornerRadius: 16))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.snappy(duration: 0.18), value: configuration.isPressed)
    }
}

private struct Hexagon: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let points = (0..<6).map { index -> CGPoint in
            let angle = Double(index) * .pi / 3 - .pi / 2
            return CGPoint(x: rect.midX + cos(angle) * rect.width / 2,
                           y: rect.midY + sin(angle) * rect.height / 2)
        }
        path.move(to: points[0])
        points.dropFirst().forEach { path.addLine(to: $0) }
        path.closeSubpath()
        return path
    }
}

@MainActor
private enum CharacterAtlas {
    enum Sprite: Int, CaseIterable {
        case hero
        case grunt
        case runner
        case tank
        case splitter
        case boss

        init(enemyKind: EnemyKind) {
            switch enemyKind {
            case .grunt: self = .grunt
            case .runner: self = .runner
            case .tank: self = .tank
            case .splitter: self = .splitter
            case .boss: self = .boss
            }
        }

        var column: Int {
            switch self {
            case .hero, .tank: 0
            case .grunt, .splitter: 1
            case .runner, .boss: 2
            }
        }

        var row: Int {
            switch self {
            case .hero, .grunt, .runner: 0
            case .tank, .splitter, .boss: 1
            }
        }
    }

    private static let images: [Sprite: Image] = {
        guard let atlas = UIImage(named: "CharacterAtlas")?.cgImage else { return [:] }
        let cellWidth = atlas.width / 3
        let cellHeight = atlas.height / 2
        return Dictionary(uniqueKeysWithValues: Sprite.allCases.compactMap { sprite in
            let cropRect = CGRect(x: sprite.column * cellWidth,
                                  y: sprite.row * cellHeight,
                                  width: cellWidth,
                                  height: cellHeight)
            guard let crop = atlas.cropping(to: cropRect) else { return nil }
            let image = Image(uiImage: UIImage(cgImage: crop, scale: 1, orientation: .up))
                .interpolation(.none)
            return (sprite, image)
        })
    }()

    static func image(for sprite: Sprite) -> Image? {
        images[sprite]
    }
}

enum GamePalette {
    static let background = Color(red: 0.025, green: 0.035, blue: 0.07)
    static let arenaTop = Color(red: 0.055, green: 0.075, blue: 0.14)
    static let arenaBottom = Color(red: 0.025, green: 0.03, blue: 0.075)
    static let lime = Color(red: 0.69, green: 1, blue: 0.2)
    static let cyan = Color(red: 0.2, green: 0.9, blue: 1)
    static let violet = Color(red: 0.55, green: 0.35, blue: 1)
    static let coral = Color(red: 1, green: 0.3, blue: 0.38)
    static let ink = Color(red: 0.018, green: 0.025, blue: 0.075)
}

private enum PixelSprites {
    static let hero = [
        ".....NNNNN.....",
        "....NCCCCCNN...",
        "...NCWWWWWCN...",
        "..NCCCVVVCCCN..",
        "..NCVLLLLLVCN..",
        "..NCVLNLNLVCN..",
        "..NCCCVVVCCCN..",
        "...NNCOOCNN....",
        "..NCCNNNNNCCN..",
        ".NCCCNCCCNCCCN.",
        ".NCCCNCCCNCCCN.",
        "..NNN.NNN.NNN..",
        "...NN.....NN...",
        "..NCCN...NCCN..",
        ".NCCCCN.NCCCCN."
    ]

    static let grunt = [
        "...NNNNN...",
        "..NAAAAAN..",
        ".NAAHAHAAN.",
        "NAAWAAAWAAN",
        "NAAEAAAEAAN",
        "NAAAAAAAAAN",
        "NAAANNNAAAN",
        ".NANWWWNAN.",
        ".NAAAAAAAN.",
        "..NNN.NNN..",
        ".NN.....NN."
    ]

    static let runner = [
        "......NN.......",
        "..NN.NAAN.NN...",
        ".NANNAAAANAAN...",
        "NAAAAWAWAAAAN..",
        ".NNAAEAEAAANN...",
        "...NAAAAAN..NN.",
        "..NNNAAANNNNANN",
        ".NN..NNN....NN..",
        "NN..........NN."
    ]

    static let tank = [
        "..NN.......NN..",
        ".NOON.....NOON.",
        "NOOONNNNNNOOON",
        "NNOAAAAAAAOONN",
        "NAAAHAAAAHAAAN",
        "NAAWAAAAAWAAAN",
        "NAAEAAAAAEAAN.",
        "NAAAANNNAAAAN.",
        "NAAANWWWNAAAN.",
        ".NAAAAAAAAAN..",
        "NNNAAANAAANNN.",
        "NAAAAANAAAAAN.",
        "NNNNNNNNNNNNN."
    ]

    static let splitter = [
        ".....NN......",
        "....NAAAN....",
        "...NAAAAAN...",
        "..NAAHAHAAN..",
        ".NAAWAAAWAAN.",
        "NAAAEAAAEAAN.",
        "NAAAAAAAAAAN.",
        "NAAAAVVVAAAN.",
        ".NAAAVVVAAAN.",
        ".NAAAAAAAAAN.",
        "NANNAANAANNAN",
        ".NN..NNNN..NN."
    ]

    static let boss = [
        "....O...O...O....",
        "...NOO.OOO.OON...",
        "...NNOOOOOOONN...",
        "..NNVVVVVVVVVNN..",
        ".NVVVAAAAAAAVVVN.",
        "NVVAAHAAAAAHAAAVN",
        "NVAAAWAAAAAWAAAVN",
        "NAAAAEAAAAAEAAAAN",
        "NAAAAAANNNAAAAAAN",
        "NAAAANWWWWWNAAAAN",
        ".NAAAANNNNNAAAAN.",
        "NNAAAAAAAAAAAAANN",
        "NVAANAAAAAAANAAVN",
        "NVANNAAAAAAANNAVN",
        ".NNN.NN...NN.NNN.",
        "NNN..NN...NN..NNN"
    ]
}

extension Upgrade {
    var color: Color {
        switch self {
        case .extraBall: GamePalette.cyan
        case .heavyCore: GamePalette.coral
        case .overdrive: GamePalette.lime
        case .fortify: GamePalette.violet
        case .criticalMass: .orange
        case .piercingRounds: GamePalette.cyan
        case .rapidVolley: GamePalette.lime
        case .lifeSteal: GamePalette.coral
        case .pulseReactor: GamePalette.violet
        case .cryoCore: .blue
        case .bountyHunter: .yellow
        case .lastStand: .red
        }
    }
}

extension UpgradeRarity {
    var color: Color {
        switch self {
        case .common: .secondary
        case .rare: GamePalette.cyan
        case .legendary: .orange
        }
    }
}

#Preview {
    ContentView()
}
