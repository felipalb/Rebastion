import Foundation

struct ScoreEntry: Codable, Sendable {
    let player: String
    let score: Int
    let wave: Int
}

enum ScoreStatus {
    case idle
    case sending
    case sent
    case offline

    var label: String {
        switch self {
        case .idle: "Placar local"
        case .sending: "Enviando pontuação…"
        case .sent: "Pontuação enviada"
        case .offline: "Salvo localmente — servidor indisponível"
        }
    }

    var symbol: String {
        switch self {
        case .idle: "internaldrive"
        case .sending: "arrow.up.circle"
        case .sent: "checkmark.circle.fill"
        case .offline: "wifi.slash"
        }
    }
}

struct ScoreService: Sendable {
    static let local = ScoreService(baseURL: URL(string: "http://127.0.0.1:8000")!)

    let baseURL: URL

    func submit(_ entry: ScoreEntry) async throws {
        var request = URLRequest(url: baseURL.appending(path: "scores"))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 3
        request.httpBody = try JSONEncoder().encode(entry)

        let (_, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }
    }
}
